class APIKey {
  // Déclaration d'une classe utilitaire (APIKey) qui sert uniquement à stocker la clé API.

  static const String apikey = "6351d8ab7df1b1f370f7dd4f7cfd3018";
  // - "static" : permet d’accéder à cette variable sans avoir à instancier la classe.
  //   Exemple : APIKey.apikey
  // - "const" : la valeur est une constante immuable, fixée à la compilation.
  // - "String apikey" : clé API sous forme de texte.
  // - Ici, la clé est stockée en dur dans le code.
}
