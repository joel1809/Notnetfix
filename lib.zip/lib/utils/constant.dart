import 'package:flutter/material.dart';

Color kBackgroundColor = const Color(0xff020202);
Color kPrimaryColor = const Color(0xffe50914);
